!function o(r, s, l) {
    function d(t, e) {
        if (!s[t]) {
            if (!r[t]) {
                var n = "function" == typeof require && require;
                if (!e && n) return n(t, !0);
                if (u) return u(t, !0);
                var a = new Error("Cannot find module '" + t + "'");
                throw a.code = "MODULE_NOT_FOUND", a
            }
            var i = s[t] = {exports: {}};
            r[t][0].call(i.exports, function (e) {
                return d(r[t][1][e] || e)
            }, i, i.exports, o, r, s, l)
        }
        return s[t].exports
    }

    for (var u = "function" == typeof require && require, e = 0; e < l.length; e++) d(l[e]);
    return d
}({
    1: [function (e, t, n) {
        "use strict";
        Object.defineProperty(n, "__esModule", {value: !0}), n.default = void 0;
        var a, i = (a = e("./gameModes.js")) && a.__esModule ? a : {default: a};

        function o(e, t) {
            for (var n = 0; n < t.length; n++) {
                var a = t[n];
                a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a)
            }
        }

        var r = ["I won!", "that goes to me!", "my point!", "one more to me.", "I won =)"],
            s = ["you won!", "you won :C", "your point", "I lost!", "I lost :'("],
            l = ["tied!", "that's a tie!", "tie!"], d = function () {
                function e() {
                    !function (e, t) {
                        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                    }(this, e), this._view = null, this._game = null, this._inPlayerMode = !0
                }

                var t, n, a;
                return t = e, (n = [{
                    key: "configure", value: function (e, t) {
                        this._view = e, this._game = t, this._game.setGameMode(i.default.classical), this._view.configure(this)
                    }
                }, {
                    key: "run", value: function () {
                        this._view.run(), this.reset()
                    }
                }, {
                    key: "reset", value: function () {
                        var e = this._getFooterButtons();
                        this._game.reset(), this._view.reset(), this._view.doCleanChat(), this._view.doHideFooter(), this._view.doShowLoading(0), this._view.doHideLoading(1e3), this._view.doAddPcMessage("Let's play!", 100), this._view.doAddPcMessage("Your move...", 1500), this._view.doAddDivider("0 x 0", 1e3), this._view.doShowFooter(e, 1e3), this._view.doUnlockFooter()
                    }
                }, {
                    key: "play", value: function (e) {
                        var t = null;
                        t = ("random" === e && (e = this._game.getRandomShapeId()), this._game.getLabel(e));
                        var n = this._game.getRandomShapeId(), a = this._game.getLabel(n), i = this._game.play(n, e),
                            o = this._getResultMessage(i), r = "".concat(a, ", ").concat(o);
                        this._view.doLockFooter(), this._view.doAddPlayerMessage(t), this._view.doAddPcMessage(r, 100), this._view.doAddDivider("".concat(this._game.score1, " x ").concat(this._game.score2), 750), this._view.doUnlockFooter(0)
                    }
                }, {
                    key: "changePlayerMode", value: function () {
                        this._inPlayerMode = !this._inPlayerMode, this.reset()
                    }
                }, {
                    key: "_getFooterButtons", value: function () {
                        return this._inPlayerMode ? this._game.getAllShapes() : [{id: "random", label: "Play"}]
                    }
                }, {
                    key: "_getResultMessage", value: function (e) {
                        var t = [];
                        return (t = -1 === e ? l : 0 === e ? r : s)[Math.floor(Math.random() * t.length)]
                    }
                }]) && o(t.prototype, n), a && o(t, a), e
            }();
        n.default = d
    }, {"./gameModes.js": 3}], 2: [function (e, t, n) {
        "use strict";

        function i(e, t) {
            for (var n = 0; n < t.length; n++) {
                var a = t[n];
                a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a)
            }
        }

        Object.defineProperty(n, "__esModule", {value: !0}), n.default = void 0;
        var a = function () {
            function e() {
                !function (e, t) {
                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                }(this, e), this._score1 = 0, this._score2 = 0, this._gameModeId = null, this._gameModeName = null, this._gameModeShapes = null, this._gameModeRules = null
            }

            var t, n, a;
            return t = e, (n = [{
                key: "setGameMode", value: function (e) {
                    if (!e) throw new Error("Invalid mode type.");
                    if ("string" != typeof e.id) throw new Error("Mode id must be a string. " + 'You provided "'.concat(e.id, '" instead.'));
                    if ("string" != typeof e.name) throw new Error("Mode name must be a string. " + 'You provided "'.concat(e.name, '" instead.'));
                    this._validateShapes(e), this._validateRules(e), this._gameModeId = e.id, this._gameModeName = e.name, this._gameModeShapes = e.shapes, this._gameModeRules = e.rules
                }
            }, {
                key: "getRandomShapeId", value: function () {
                    var e = Math.floor(Math.random() * this._gameModeShapes.length);
                    return this._gameModeShapes[e].id
                }
            }, {
                key: "getAllShapes", value: function () {
                    return JSON.parse(JSON.stringify(this._gameModeShapes))
                }
            }, {
                key: "check", value: function (e, t) {
                    var n = this._gameModeRules[e], a = this._gameModeRules[t];
                    return n && 0 <= n.indexOf(t) ? 0 : a && 0 <= a.indexOf(e) ? 1 : -1
                }
            }, {
                key: "getLabel", value: function (e) {
                    for (var t = 0; t < this._gameModeShapes.length; t++) if (this._gameModeShapes[t].id === e) return this._gameModeShapes[t].label;
                    return null
                }
            }, {
                key: "reset", value: function () {
                    this._score1 = 0, this._score2 = 0
                }
            }, {
                key: "play", value: function (e, t) {
                    var n = this.check(e, t);
                    return 0 === n ? this._score1 += 1 : 1 === n && (this._score2 += 1), n
                }
            }, {
                key: "_validateShapes", value: function (e) {
                    if (!Array.isArray(e.shapes)) throw new Error("Invalid shape type.");
                    if (e.shapes.length <= 2) throw new Error("Mode must have at least 3 shapes.");
                    for (var t = [], n = [], a = 0; a < e.shapes.length; a++) {
                        var i = e.shapes[a];
                        if (!i || !i.id || !i.label) throw new Error("Invalid shape element.");
                        if (0 <= t.indexOf(i.id)) throw new Error('Duplicated shape id "'.concat(i.id, '".'));
                        if (0 <= n.indexOf(i.label)) throw new Error('Duplicated shape label "'.concat(i.label, '".'));
                        t.push(i.id), n.push(i.label)
                    }
                }
            }, {
                key: "_validateRules", value: function (e) {
                    if (!e.rules || !Object.keys(e.rules)) throw new Error("Invalid rules type.");
                    for (var t = e.shapes.map(function (e) {
                        return e.id
                    }), n = t.map(function (e) {
                        return e
                    }), a = t.map(function (e) {
                        return e
                    }), i = Object.keys(e.rules), o = 0; o < i.length; o++) {
                        var r = i[o], s = e.rules[r];
                        if (-1 === t.indexOf(r)) throw new Error("Invalid rules element.");
                        var l = n.indexOf(r);
                        0 <= l && n.splice(l, 1);
                        for (var d = 0; d < s.length; d++) {
                            var u = s[d];
                            if (-1 === t.indexOf(u)) throw new Error("Invalid rules element.");
                            var c = a.indexOf(u);
                            0 <= c && a.splice(c, 1)
                        }
                    }
                    if (n.length || a.length) throw new Error("Missing shape.")
                }
            }, {
                key: "score1", get: function () {
                    return this._score1
                }
            }, {
                key: "score2", get: function () {
                    return this._score2
                }
            }]) && i(t.prototype, n), a && i(t, a), e
        }();
        n.default = a
    }, {}], 3: [function (e, t, n) {
        "use strict";
        Object.defineProperty(n, "__esModule", {value: !0}), n.default = void 0;
        var a = {
            classical: {
                id: "classical",
                name: "Classical",
                shapes: [{id: "paper", label: "Paper"}, {id: "rock", label: "Rock"}, {id: "scissor", label: "Scissor"}],
                rules: {paper: ["rock"], scissor: ["paper"], rock: ["scissor"]}
            }
        };
        n.default = a
    }, {}], 4: [function (l, e, t) {
        (function (e) {
            "use strict";
            var t = i(l("./app.js")), n = i(l("./game.js")), a = i(l("./view.js"));

            function i(e) {
                return e && e.__esModule ? e : {default: e}
            }

            var o = new t.default, r = new a.default, s = new n.default;
            o.configure(r, s), o.run(), e.$view = r
        }).call(this, "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {})
    }, {"./app.js": 1, "./game.js": 2, "./view.js": 5}], 5: [function (e, t, n) {
        "use strict";
        Object.defineProperty(n, "__esModule", {value: !0}), n.default = void 0;
        var i = function (e) {
            {
                if (e && e.__esModule) return e;
                var t = {};
                if (null != e) for (var n in e) if (Object.prototype.hasOwnProperty.call(e, n)) {
                    var a = Object.defineProperty && Object.getOwnPropertyDescriptor ? Object.getOwnPropertyDescriptor(e, n) : {};
                    a.get || a.set ? Object.defineProperty(t, n, a) : t[n] = e[n]
                }
                return t.default = e, t
            }
        }(e("./viewHelpers.js"));

        function o(e, t) {
            for (var n = 0; n < t.length; n++) {
                var a = t[n];
                a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, a.key, a)
            }
        }

        var a = function () {
            function e() {
                !function (e, t) {
                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                }(this, e), this._animationPool = [], this._chatElement = null, this._footerElement = null, this._bodyElement = null, this._previousTime = null
            }

            var t, n, a;
            return t = e, (n = [{
                key: "configure", value: function (e) {
                    this._app = e, this._chatElement = document.getElementsByClassName("cup-chat")[0], this._footerElement = document.getElementsByClassName("cup-game-footer")[0], this._bodyElement = document.getElementsByClassName("cup-game-body")[0]
                }
            }, {
                key: "actionReset", value: function () {
                    this._app.reset()
                }
            }, {
                key: "actionChangePlayerMode", value: function () {
                    this._app.changePlayerMode()
                }
            }, {
                key: "actionPlay", value: function (e) {
                    this._app.play(e)
                }
            }, {
                key: "doCleanChat", value: function () {
                    var e = this, t = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : 0;
                    this._addAnimation(function () {
                        e._chatElement.innerHTML = ""
                    }, t)
                }
            }, {
                key: "doAddPlayerMessage", value: function (t) {
                    var n = this, e = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : 0;
                    this._addAnimation(function () {
                        var e = i.createChatBubble("right", "player", t);
                        i.addChild(n._chatElement, e), i.scrollDown(n._bodyElement)
                    }, e)
                }
            }, {
                key: "doAddPcMessage", value: function (t) {
                    var n = this, e = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : 0;
                    this._addAnimation(function () {
                        var e = i.createChatBubble("left", "pc", t);
                        i.addChild(n._chatElement, e), i.scrollDown(n._bodyElement)
                    }, e)
                }
            }, {
                key: "doAddDivider", value: function (t) {
                    var n = this, e = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : 0;
                    this._addAnimation(function () {
                        var e = i.createChatDivider(t);
                        i.addChild(n._chatElement, e), i.scrollDown(n._bodyElement)
                    }, e)
                }
            }, {
                key: "doLockFooter", value: function () {
                    var e = this, t = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : 0;
                    this._addAnimation(function () {
                        i.addClass(e._footerElement, "locked")
                    }, t)
                }
            }, {
                key: "doUnlockFooter", value: function () {
                    var e = this, t = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : 0;
                    this._addAnimation(function () {
                        i.removeClass(e._footerElement, "locked")
                    }, t)
                }
            }, {
                key: "doShowFooter", value: function (n) {
                    var a = this, e = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : 0;
                    this._addAnimation(function () {
                        i.removeChildren(a._footerElement);
                        for (var e = 0; e < n.length; e++) {
                            var t = i.createFooterButton(n[e].id, n[e].label);
                            i.addChild(a._footerElement, t)
                        }
                        i.removeClass(a._footerElement, "hidden")
                    }, e)
                }
            }, {
                key: "doHideFooter", value: function () {
                    var e = this, t = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : 0;
                    this._addAnimation(function () {
                        i.addClass(e._footerElement, "hidden")
                    }, t)
                }
            }, {
                key: "doShowLoading", value: function () {
                    var t = this, e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : 0;
                    this._addAnimation(function () {
                        if (!document.getElementsByClassName("loading").length) {
                            var e = i.createChatBubble("left loading", "pc", '<i class="fa fa-spinner fa-fw fa-spin"></i>');
                            i.addChild(t._chatElement, e), i.scrollDown(t._bodyElement)
                        }
                    }, e)
                }
            }, {
                key: "doHideLoading", value: function () {
                    var n = this, e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : 0;
                    this._addAnimation(function () {
                        for (var e = document.getElementsByClassName("loading"), t = 0; t < e.length; t++) n._chatElement.removeChild(e[t])
                    }, e)
                }
            }, {
                key: "reset", value: function () {
                    this._animationPool = []
                }
            }, {
                key: "run", value: function () {
                    this._previousTime = Date.now(), this._update()
                }
            }, {
                key: "_addAnimation", value: function (e, t) {
                    this._animationPool.push({
                        fn: function () {
                            return e()
                        }, duration: t
                    })
                }
            }, {
                key: "_tick", value: function () {
                    var e = Date.now();
                    if (this._animationPool.length) {
                        var t = this._animationPool[0], n = e - this._previousTime;
                        t.duration -= n, t.duration <= 0 && (t.fn(), this._animationPool.shift())
                    }
                    this._previousTime = e
                }
            }, {
                key: "_update", value: function () {
                    var e = this;
                    window.requestAnimationFrame(function () {
                        e._update()
                    }), this._tick()
                }
            }]) && o(t.prototype, n), a && o(t, a), e
        }();
        n.default = a
    }, {"./viewHelpers.js": 6}], 6: [function (e, t, n) {
        "use strict";
        Object.defineProperty(n, "__esModule", {value: !0}), n.createChatBubble = function (e, t, n) {
            var a = document.createElement("div");
            a.className = "cup-chat-row ".concat(e);
            var i = document.createElement("div");
            return i.className = "cup-chat-bubble ".concat(t), i.innerHTML = n, a.appendChild(i), a
        }, n.createChatDivider = function (e) {
            var t = document.createElement("div");
            t.className = "cup-chat-row center";
            var n = document.createElement("div");
            return n.className = "cup-chat-divider", n.innerHTML = e, t.appendChild(n), t
        }, n.createFooterButton = function (e, t) {
            var n = document.createElement("a");
            n.className = "cup-button footer";
            var a = document.createElement("i");
            return a.className = i[e], a.onclick = function () {
                return $view.actionPlay(e)
            }, n.appendChild(a), n
        }, n.addChild = function (e, t) {
            e.appendChild(t)
        }, n.removeChildren = function (e) {
            e.innerHTML = ""
        }, n.addClass = function (e, t) {
            var n = new RegExp("(?:^|\\s)".concat(t, "(?!\\S)"), "g");
            if (e.className.match(n)) return;
            e.className += " ".concat(t)
        }, n.removeClass = function (e, t) {
            var n = new RegExp("(?:^|\\s)".concat(t, "(?!\\S)"), "g");
            e.className = e.className.replace(n, "")
        }, n.scrollDown = function (e) {
            e.scrollTop = e.scrollHeight
        };
        var i = {
            random: "fa fa-fw fa-play-circle",
            paper: "fa fa-fw fa-hand-paper-o",
            rock: "fa fa-fw fa-hand-rock-o",
            scissor: "fa fa-fw fa-hand-scissors-o"
        }
    }, {}]
}, {}, [4]);
//# sourceMappingURL=maps/app.js.map
